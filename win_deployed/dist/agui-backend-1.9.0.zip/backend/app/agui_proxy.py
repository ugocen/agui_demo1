"""AG-UI proxy.

POST /api/agui/{agent_id} looks up the agent in the DB catalog (populated from
AgentCore, never from env), forwards the AG-UI request to that runtime's
AgentCore invocation endpoint, and pipes the SSE stream back unchanged. The
upstream call is always SigV4-signed with the host's AWS credentials; in entra
mode the caller's Entra token has already been validated at the platform
boundary, so the backend calls AgentCore as the trusted caller. httpx streaming,
no buffering.
"""

import json
import os
import urllib.parse
import uuid

import boto3
import httpx
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.exceptions import BotoCoreError, ClientError
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents_catalog import get_agent
from app.auth import require_platform_access
from app.db import get_session
from app.logging_setup import get_logger

router = APIRouter()
log = get_logger("proxy")

SESSION_HEADER = "X-Amzn-Bedrock-AgentCore-Runtime-Session-Id"
MIN_SESSION_ID_LENGTH = 33


def invocation_url(runtime_arn: str, region: str) -> str:
    escaped_arn = urllib.parse.quote(runtime_arn, safe="")
    return (
        f"https://bedrock-agentcore.{region}.amazonaws.com"
        f"/runtimes/{escaped_arn}/invocations?qualifier=DEFAULT"
    )


def session_id_from_thread(body: bytes) -> str:
    try:
        thread_id = str(json.loads(body).get("threadId") or "")
    except (ValueError, AttributeError):
        thread_id = ""
    session_id = thread_id or "phase0-session"
    if len(session_id) < MIN_SESSION_ID_LENGTH:
        session_id = session_id + "-" + "0" * MIN_SESSION_ID_LENGTH
    return session_id[:100]


def sigv4_headers(url: str, body: bytes, region: str, base_headers: dict) -> dict:
    """SigV4-sign the upstream AgentCore call with the host's AWS credentials.

    Credentials here are usually a short-lived `aws login` session, so resolving
    them FAILS as a matter of course once it expires: botocore raises
    LoginRefreshRequired (a BotoCoreError) out of `get_frozen_credentials()`.
    Uncaught, that left FastAPI to return its bare-text 500 — which, being raised
    outside CORSMiddleware, reaches the browser with no CORS headers and shows up
    as an opaque `TypeError: Failed to fetch`. Every agent looked broken and the
    one thing the user had to do was invisible. Convert it to a 503 that says so.
    """
    try:
        credentials = boto3.Session().get_credentials()
        if credentials is None:
            raise HTTPException(
                status_code=503,
                detail="no AWS credentials available for SigV4 — sign in with `aws login`",
            )
        frozen = credentials.get_frozen_credentials()
    except (BotoCoreError, ClientError) as error:
        raise HTTPException(
            status_code=503,
            detail=f"AWS credentials unavailable — re-authenticate with `aws login` ({type(error).__name__}: {error})",
        )
    aws_request = AWSRequest(method="POST", url=url, data=body, headers=base_headers)
    SigV4Auth(frozen, "bedrock-agentcore", region).add_auth(aws_request)
    return dict(aws_request.headers)


@router.post("/api/agui/{agent_id}")
async def proxy_agui(
    agent_id: str,
    request: Request,
    user: dict = Depends(require_platform_access),
    db: AsyncSession = Depends(get_session),
):
    agent = await get_agent(db, agent_id)
    if agent is None:
        raise HTTPException(status_code=404, detail=f"unknown agent {agent_id}")

    body = await request.body()
    session_id = session_id_from_thread(body)
    headers = {
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
        SESSION_HEADER: session_id,
    }
    log.debug(
        "proxy %s: auth_mode=%s user=%s session=%s body=%dB",
        agent_id,
        user.get("mode"),
        user.get("user", "-"),
        session_id[:16],
        len(body),
    )

    # The runtime ARN comes from the DB catalog entry (synced from AgentCore),
    # never from env. An empty ARN means the catalog is stale / the runtime was
    # removed from AgentCore — re-sync to fix.
    runtime_arn = agent["runtime_arn"]
    if not runtime_arn:
        raise HTTPException(
            status_code=503,
            detail=f"agent {agent_id} has no AgentCore runtime ARN in the catalog — re-sync the catalog",
        )
    region = os.environ.get("AWS_REGION", "")
    if not region:
        raise HTTPException(status_code=500, detail="AWS_REGION is not set")
    url = invocation_url(runtime_arn, region)
    # Runtimes are deployed with IAM auth, so the AgentCore call is always
    # SigV4-signed regardless of the app-level auth mode. In entra mode the
    # backend has already validated the user's Entra ID token (SSO at the platform
    # boundary) and now acts as the trusted caller — the "backend exchanges the
    # token and calls AgentCore with SigV4" pattern. The user's identity stays in
    # the request context (user["user"]) but is not forwarded upstream.
    headers = sigv4_headers(url, body, region, headers)
    log.debug("proxy %s -> AgentCore (SigV4) %s", agent_id, url.split("?")[0])

    client = httpx.AsyncClient(timeout=httpx.Timeout(connect=10, read=None, write=30, pool=10))
    upstream_request = client.build_request("POST", url, content=body, headers=headers)
    try:
        upstream = await client.send(upstream_request, stream=True)
    except httpx.HTTPError as error:
        await client.aclose()
        raise HTTPException(status_code=502, detail=f"upstream connection failed: {error}")

    if upstream.status_code != 200:
        detail = (await upstream.aread()).decode(errors="replace")
        await upstream.aclose()
        await client.aclose()
        log.warning("proxy %s upstream returned %s: %s", agent_id, upstream.status_code, detail[:200])
        raise HTTPException(status_code=upstream.status_code, detail=detail[:1000])

    log.debug("proxy %s upstream 200, streaming SSE back", agent_id)

    async def pipe():
        try:
            async for chunk in upstream.aiter_raw():
                yield chunk
        finally:
            await upstream.aclose()
            await client.aclose()

    media_type = upstream.headers.get("content-type", "text/event-stream")
    return StreamingResponse(pipe(), media_type=media_type)


@router.get("/api/agui/{agent_id}/health")
async def agui_health(
    agent_id: str,
    user: dict = Depends(require_platform_access),
    db: AsyncSession = Depends(get_session),
) -> dict:
    """Liveness probe for one agent — is its runtime actually up?

    The control plane reports a runtime READY even when its container cannot
    boot (the port bug of 2026-07-15 sat behind a READY runtime), so the only
    truthful check is a real invoke. This opens an AG-UI run and stops at the
    first event: RUN_STARTED is emitted before the model is called, so reaching
    it proves the whole path (catalog -> proxy -> SigV4 -> AgentCore -> the
    container booted -> the agent started) at near-zero token cost.

    Unlike the proxy route, this returns JSON (not an SSE stream) and reads only
    the first event, so it does not stream to the browser and does not violate
    the "never buffer the proxy" invariant — it is a separate liveness endpoint.
    """
    agent = await get_agent(db, agent_id)
    if agent is None:
        raise HTTPException(status_code=404, detail=f"unknown agent {agent_id}")

    runtime_arn = agent["runtime_arn"]
    if not runtime_arn:
        return {
            "agent_id": agent_id,
            "alive": False,
            "detail": "no AgentCore runtime ARN in the catalog — re-sync the catalog",
        }
    region = os.environ.get("AWS_REGION", "")
    if not region:
        raise HTTPException(status_code=500, detail="AWS_REGION is not set")

    payload = {
        "threadId": f"health-{uuid.uuid4().hex}",
        "runId": f"run-{uuid.uuid4().hex[:8]}",
        "messages": [{"id": f"msg-{uuid.uuid4().hex[:8]}", "role": "user", "content": "ping"}],
        "tools": [],
        "context": [],
        "state": {},
        "forwardedProps": {},
    }
    body = json.dumps(payload).encode()
    session_id = session_id_from_thread(body)
    base_headers = {
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
        SESSION_HEADER: session_id,
    }
    url = invocation_url(runtime_arn, region)
    # This endpoint answers "is the agent up?" with a verdict, and the banner is
    # the only place the user ever sees it — so report a local credential failure
    # as the verdict's detail rather than raising it into an opaque fetch error.
    try:
        headers = sigv4_headers(url, body, region, base_headers)
    except HTTPException as error:
        return {"agent_id": agent_id, "alive": False, "detail": str(error.detail)}

    # AgentCore takes ~30s to give up on an unhealthy runtime; read generously so
    # that verdict is captured rather than the request timing out first.
    timeout = httpx.Timeout(connect=10, read=60, write=30, pool=10)
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("POST", url, content=body, headers=headers) as upstream:
                if upstream.status_code != 200:
                    detail = (await upstream.aread()).decode(errors="replace")
                    return {"agent_id": agent_id, "alive": False, "detail": f"HTTP {upstream.status_code}: {detail[:200]}"}
                async for line in upstream.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    try:
                        event = json.loads(line[6:])
                    except ValueError:
                        continue
                    etype = event.get("type")
                    if etype == "RUN_STARTED":
                        return {"agent_id": agent_id, "alive": True, "detail": "container booted, agent running"}
                    if etype == "RUN_ERROR":
                        return {"agent_id": agent_id, "alive": False, "detail": (event.get("message") or "RUN_ERROR")[:220]}
                return {"agent_id": agent_id, "alive": False, "detail": "stream closed without RUN_STARTED"}
    except httpx.HTTPError as error:
        return {"agent_id": agent_id, "alive": False, "detail": f"{type(error).__name__}: {error}"}
