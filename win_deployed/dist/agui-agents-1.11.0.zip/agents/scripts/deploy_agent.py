# /// script
# requires-python = ">=3.11"
# dependencies = ["boto3==1.43.46", "botocore[crt]==1.43.46"]
# ///
"""Deploy one agent zip to Bedrock AgentCore Runtime via direct code deployment.

Usage: uv run scripts/deploy_agent.py <agent-name> <zip-path>

Uploads the zip to s3://$DEPLOY_BUCKET/<agent-name>/deployment_package.zip,
updates the agent runtime, waits for READY and prints the runtime ARN.

Inbound auth is chosen PER AGENT (JWT_AUTH_AGENTS below, overridable with
--auth=iam|jwt), not from AUTH_MODE. A runtime is either IAM-authorized — the
backend proxy SigV4-signs the call and the caller's identity stops at the
platform boundary — or JWT-authorized, where AgentCore validates the user's own
Entra token and the proxy forwards it. Reading that choice from AUTH_MODE, as
this script used to, meant flipping every runtime to JWT the moment browser SSO
was switched on, leaving the SigV4 agents rejecting the proxy that routes to
them.

The deploy target is resolved CATALOG-FIRST. The backend proxy routes on the
platform DB catalog entry's runtime_arn (backend/phase0.db, table
agent_catalog) — not on any naming convention — so that ARN is the runtime the
live app actually serves. Several live runtimes were hand-created under names
the convention cannot derive (e.g. Planner-QIXryP8Qvh for
sdlc-planner-strands); deploying by convention updated or created a same-named
twin runtime the app never routes to, leaving the app on stale code. Per agent
this script therefore:

1. resolves the catalog entry (CATALOG_AGENT_IDS map first, then a row whose
   runtime_name matches the name-derived runtime) and updates THAT runtime,
   warning loudly when the convention would have picked a different one;
2. falls back to the old find-or-create by derived name ("-" -> "_") only when
   no catalog entry is reachable — the first deploy of a brand-new agent. The
   catalog auto-registers the new runtime on its next AgentCore sync.

Configuration is read from the .env file in this script's parent directory
(the repo root in the monorepo layout; the agents/ folder when this script
ships alongside the agents). The catalog DB is expected at backend/phase0.db
next to it; set CATALOG_DB_PATH in that .env when the backend's SQLite file
lives elsewhere. A non-SQLite catalog (Postgres DATABASE_URL) cannot be read
here — the name-derived fallback then applies, so verify the catalog ARN after
deploying. Runtime ARNs are never written back to .env: the catalog is their
only home (AGENTS.md invariant 2).
"""

import sqlite3
import sys
import time
from pathlib import Path

import boto3
from boto3.s3.transfer import TransferConfig
from botocore.config import Config
from botocore.exceptions import ClientError

# The zips are 37-51 MB since ADOT landed, and boto3's defaults upload them as
# ten concurrent 8 MB parts. On a modest uplink that splits the bandwidth ten
# ways, every part then idles past the 60s socket timeout, and all four retries
# burn the same way — the upload fails after minutes with RequestTimeout on
# UploadPart, which reads like an AWS problem and is not one. Four larger parts
# and a longer read timeout keep each part moving.
S3_CONFIG = Config(
    connect_timeout=30,
    read_timeout=300,
    retries={"max_attempts": 6, "mode": "adaptive"},
)
S3_TRANSFER = TransferConfig(
    multipart_chunksize=16 * 1024 * 1024,
    max_concurrency=4,
)

PHASE0_DIR = Path(__file__).resolve().parent.parent
ENV_PATH = PHASE0_DIR / ".env"
DEFAULT_CATALOG_DB = PHASE0_DIR / "backend" / "phase0.db"

# Agent directory -> platform catalog agent_id (agent_catalog.agent_id); also
# the allowlist of deployable agent names. The five original ids were picked by
# hand before the runtime naming convention existed, so they cannot be derived.
# A brand-new agent's auto-registered id is the slug of its runtime name, which
# equals the directory name — add it here as itself.
CATALOG_AGENT_IDS = {
    "sdlc-planner-strands": "planner",
    "release-readiness-langgraph": "release",
    "bug-report-strands": "bugreport",
    "a2ui-demo-strands": "a2uidemo",
    "press-release-strands": "pressrelease",
    # Deployed after the convention existed: the runtime is named
    # jira_story_strands, whose slug is the directory name, so it maps to itself.
    "jira-story-strands": "jira-story-strands",
    "whoami-strands": "whoami-strands",
}

# Agents whose runtime takes the caller's Entra token directly, via AgentCore's
# inbound JWT authorizer, instead of the SigV4/IAM auth every other runtime uses.
#
# This is per-agent and cannot be a global switch: a runtime is EITHER
# IAM-authorized or JWT-authorized, and the backend proxy signs its call
# accordingly (SigV4 vs forwarding the user's bearer). Flipping every runtime to
# JWT because AUTH_MODE happens to say `entra` — which is what this script used
# to do — would leave the five SigV4 agents rejecting every request from the very
# proxy that routes to them, for a setting whose name is about *browser* sign-in.
JWT_AUTH_AGENTS = {"whoami-strands"}

# AgentCore forwards NO request header to agent code unless the runtime allowlists
# it. Not the caller's bearer, and not the `X-Amzn-Bedrock-AgentCore-Runtime-Custom-`
# headers either — that prefix only makes a header *eligible* to be allowlisted; it
# has never been enough on its own. A runtime deployed without this reaches agent
# code with exactly two headers, both injected by the platform (`baggage`,
# `workloadaccesstoken`), which is why whoami-strands answered "no user token
# reached this runtime" for a request AgentCore had just authenticated.
#
# Set on every runtime, not just the JWT one: the relay is a platform feature
# (AGENT_TOKEN_RELAY), any agent may become identity-aware, and the cap is 20
# headers. `Authorization` is the exception — the API only accepts it on a runtime
# that has a customJWTAuthorizer, so it is added per inbound auth below.
# https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime-header-allowlist.html
RELAY_HEADERS = [
    "X-Amzn-Bedrock-AgentCore-Runtime-Custom-Id-Token",
    "X-Amzn-Bedrock-AgentCore-Runtime-Custom-Graph-Token",
]

READY_TIMEOUT_SECONDS = 300
POLL_SECONDS = 5


def build_env_vars(env: dict, control, existing_runtime_id: str | None) -> dict:
    """Runtime environment variables for the agent: model id + optional gateway config.

    On UPDATE, start from the runtime's current environmentVariables. AgentCore's
    update_agent_runtime REPLACES the whole map, so without this merge a redeploy
    would silently strip values set out-of-band — most importantly the enterprise
    gateway config entered in the console, which the enterprise agents cannot
    start without.

    This script serves BOTH copies (AGENTS.md invariant 4), which is why the
    gateway variables are passed through rather than required: deploying a
    Phase0/agents/ (Bedrock-only) agent legitimately has none, while a
    cloud_deploy/agents/ (gateway-only) agent needs all of BEDROCK_ENDPOINT_URL,
    BEDROCK_API_KEY and BEDROCK_MODEL_ID. The agent itself enforces that — it
    raises at startup — so the check lives where it can tell the two apart. The
    cost is that a gateway agent deployed without them fails at runtime, not
    here, and the symptom is an unhelpful initialization timeout; the real error
    is in the runtime's [runtime-logs] CloudWatch stream.
    """
    merged: dict = {}
    if existing_runtime_id:
        try:
            detail = control.get_agent_runtime(agentRuntimeId=existing_runtime_id)
            merged.update(detail.get("environmentVariables") or {})
        except ClientError as error:
            print(f"WARN: could not read existing env vars, not merging: {error}")

    merged["BEDROCK_MODEL_ID"] = require(env, "BEDROCK_MODEL_ID")
    for key in (
        "BEDROCK_ENDPOINT_URL",
        "BEDROCK_API_KEY",
        "BEDROCK_STREAMING",
        # Identity config, for an agent that reads the caller's token
        # (whoami-strands). Passed through the same way as the gateway variables
        # and for the same reason: only one agent uses them, none of the others
        # is harmed by their presence, and requiring them here would block the
        # deploy of every agent that has no idea what they are.
        "ENTRA_TENANT_ID",
        "GRAPH_OBO_PROVIDER_NAME",
        "GRAPH_OBO_SCOPES",
    ):
        value = env.get(key, "").strip()
        if value:
            merged[key] = value
    # Resolved, not copied: the agent re-verifies the token it is handed, and it
    # must pin the SAME audience the runtime's authorizer does or the two
    # disagree about what a valid token is.
    audience = entra_audience(env)
    if audience:
        merged["ENTRA_ALLOWED_AUDIENCE"] = audience
    return merged


def entra_audience(env: dict) -> str:
    """The `aud` the browser's token carries, for the authorizer AND the agent.

    Defaults to the SPA client id because the default agent token is an Entra ID
    token, whose audience is exactly that. One function so the runtime's
    authorizer and the agent's own re-verification can never pin different values.
    """
    return env.get("ENTRA_ALLOWED_AUDIENCE", "").strip() or env.get("ENTRA_SPA_CLIENT_ID", "").strip()


def load_env(required: bool = True) -> dict:
    """Parse the .env next to this script's parent into a plain dict.

    `required=False` is for invoke_agentcore.py, which shares this: it only wants
    AWS_REGION and CATALOG_DB_PATH, both optional, and must stay runnable in a
    checkout that has no .env at all.
    """
    if not ENV_PATH.exists():
        if not required:
            return {}
        sys.exit(f"FAIL: {ENV_PATH} not found, copy .env.example to .env and fill it")
    values = {}
    for line in ENV_PATH.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        values[key.strip()] = value.strip()
    return values


def require(env: dict, key: str) -> str:
    value = env.get(key, "")
    if not value:
        sys.exit(f"FAIL: {key} is empty in .env, fill it first ([Human] prerequisite)")
    return value


def ensure_bucket(s3, bucket: str, region: str) -> None:
    try:
        s3.head_bucket(Bucket=bucket)
        return
    except ClientError as error:
        code = error.response["Error"]["Code"]
        if code not in ("404", "NoSuchBucket"):
            raise
    print(f"Bucket {bucket} not found, creating it")
    create_kwargs = {"Bucket": bucket}
    if region != "us-east-1":
        create_kwargs["CreateBucketConfiguration"] = {"LocationConstraint": region}
    s3.create_bucket(**create_kwargs)


def runtime_name_for(agent_name: str) -> str:
    return agent_name.replace("-", "_")


def list_runtimes(control) -> list[dict]:
    """Every agent runtime in the region, all pages.

    One place, so that a lookup and the "these are the names that exist" text in
    its failure message are always built from the same call. invoke_agentcore.py
    used to search live runtimes but print a hardcoded list of names it had never
    searched, and so could deny a name while listing it as known.
    """
    runtimes: list[dict] = []
    token = None
    while True:
        kwargs = {"maxResults": 100}
        if token:
            kwargs["nextToken"] = token
        page = control.list_agent_runtimes(**kwargs)
        runtimes.extend(page.get("agentRuntimes", []))
        token = page.get("nextToken")
        if not token:
            return runtimes


def resolve_target(control, target: str):
    """Find the runtime an explicit --runtime flag names, by runtime name or ARN.

    --runtime is the escape hatch for updating a runtime whose name this script's
    naming convention could not derive — e.g. one created by hand in the AgentCore
    console under an arbitrary name (four of the five runtimes in the personal
    account are exactly this: Planner / Release_Readiness / Press_Release /
    A2UI_demo). The default path is the catalog-first resolution in main(); this
    only runs when --runtime is given, and exits if the name/ARN is not found.
    """
    key = "agentRuntimeArn" if target.startswith("arn:") else "agentRuntimeName"
    runtimes = list_runtimes(control)
    match = next((runtime for runtime in runtimes if runtime.get(key) == target), None)
    if match is None:
        known = ", ".join(sorted(r.get("agentRuntimeName", "") for r in runtimes)) or "(none)"
        sys.exit(
            f"FAIL: --runtime={target} not found. Runtimes in this region: {known}. "
            "Deploy without --runtime to create a new one."
        )
    return match


def find_existing_runtime(control, runtime_name: str):
    return next(
        (r for r in list_runtimes(control) if r.get("agentRuntimeName") == runtime_name),
        None,
    )


def resolve_catalog_target(env: dict, agent_name: str, derived_name: str) -> dict | None:
    """Look up the deploy target in the platform catalog DB — the same table the
    backend proxy routes on. Returns None (after printing why) when no entry is
    reachable, which sends the caller down the name-derived fallback.

    Read-only, at deploy time only; no ARN ends up in env or config, so
    AGENTS.md invariant 2 stands. Matches the explicit CATALOG_AGENT_IDS map
    first, then a row whose runtime_name equals the name-derived runtime (an
    agent that only ever existed by convention). Also picks up a duplicate row
    pointing at the name-derived runtime so a stray auto-registration is called
    out instead of silently coexisting with the real entry.

    `agent_name` falls back to itself when it is not an agent directory name, so
    invoke_agentcore.py — which shares this and must resolve identically or it
    probes a runtime other than the one deployed to — can also pass a catalog
    agent id ('a2uidemo') straight through. main() checks the allowlist before
    calling this, so that fallback never changes a deploy.
    """
    configured = env.get("CATALOG_DB_PATH", "").strip()
    db_path = Path(configured).expanduser() if configured else DEFAULT_CATALOG_DB
    if not db_path.exists():
        print(f"Catalog DB not found at {db_path} — using the name-derived runtime")
        return None
    query = "SELECT agent_id, runtime_name, runtime_arn FROM agent_catalog WHERE {} = ?"
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except sqlite3.Error as error:
        print(f"WARN: cannot open catalog DB {db_path} ({error}) — using the name-derived runtime")
        return None
    try:
        conn.row_factory = sqlite3.Row
        agent_id = CATALOG_AGENT_IDS.get(agent_name, agent_name)
        row = conn.execute(query.format("agent_id"), (agent_id,)).fetchone()
        if row is None:
            row = conn.execute(query.format("runtime_name"), (derived_name,)).fetchone()
        if row is None:
            print(f"No catalog entry for {agent_name} in {db_path} — using the name-derived runtime")
            return None
        duplicate = conn.execute(
            "SELECT agent_id, runtime_arn FROM agent_catalog WHERE runtime_name = ? AND agent_id != ?",
            (derived_name, row["agent_id"]),
        ).fetchone()
    except sqlite3.Error as error:
        print(f"WARN: catalog DB query failed ({error}) — using the name-derived runtime")
        return None
    finally:
        conn.close()
    return {
        "agent_id": row["agent_id"],
        "runtime_name": row["runtime_name"],
        "runtime_arn": row["runtime_arn"],
        "duplicate": dict(duplicate) if duplicate else None,
    }


def warn_catalog_divergence(control, catalog: dict, derived_name: str) -> None:
    """The failure mode this script guards against: the catalog routes the agent
    to a runtime the naming convention cannot reach, so a name-derived deploy
    would update (or create) a twin the app never serves. Make the divergence
    impossible to miss, and point at any twin that already exists."""
    bar = "!" * 78
    lines = [
        bar,
        "!! WARNING: the name-derived runtime and the catalog target DISAGREE.",
        f"!!   catalog '{catalog['agent_id']}' routes to : {catalog['runtime_arn']}",
        f"!!   the naming convention would pick : {derived_name}",
        "!! Deploying to the CATALOG runtime — the one the live app actually serves.",
    ]
    twin = find_existing_runtime(control, derived_name)
    if twin and twin.get("agentRuntimeArn") != catalog["runtime_arn"]:
        lines += [
            f"!! A separate runtime named {derived_name} also exists:",
            f"!!   {twin.get('agentRuntimeArn')}",
            "!! The app does not route this agent there (a twin from an old name-derived",
            "!! deploy). Until it is deleted, every catalog sync re-registers it as a",
            "!! duplicate agent entry.",
        ]
    if catalog["duplicate"]:
        dup = catalog["duplicate"]
        lines += [
            f"!! The catalog also holds a duplicate entry '{dup['agent_id']}' pointing at",
            f"!!   {dup['runtime_arn']}",
            "!! Disable or delete it on /admin — it is a stray auto-registration.",
        ]
    lines.append(bar)
    print("\n".join(lines))


def jwt_authorizer(env: dict) -> dict:
    """The `customJWTAuthorizer` config for an agent that takes the user's token.

    Everything here can be derived from the two Entra values the platform already
    needs (ENTRA_TENANT_ID, ENTRA_SPA_CLIENT_ID), so turning a runtime into a
    JWT-authorized one costs no new configuration — the explicit ENTRA_DISCOVERY_URL
    / ENTRA_ALLOWED_AUDIENCE / ENTRA_ALLOWED_CLIENTS still win when set.

    The audience default is the SPA client id because the token the browser sends
    is an Entra **ID token**, whose `aud` is exactly that. The alternative — an
    access token for an "Expose an API" scope — is the more orthodox choice but
    needs an app-registration change, and one specific trap: unless that app's
    manifest sets `accessTokenAcceptedVersion: 2`, Entra issues a v1 token whose
    issuer is `https://sts.windows.net/<tid>/`, which will never match the v2.0
    discovery document's issuer and is rejected with no useful error. If you go
    that route, set both ENTRA_ALLOWED_AUDIENCE (`api://<client-id>`) and the
    manifest field.
    """
    tenant = env.get("ENTRA_TENANT_ID", "").strip()
    discovery = env.get("ENTRA_DISCOVERY_URL", "").strip()
    if not discovery:
        if not tenant:
            sys.exit(
                "FAIL: --auth=jwt needs ENTRA_TENANT_ID (or an explicit ENTRA_DISCOVERY_URL) in .env"
            )
        discovery = f"https://login.microsoftonline.com/{tenant}/v2.0/.well-known/openid-configuration"

    audience = entra_audience(env)
    clients = [c.strip() for c in env.get("ENTRA_ALLOWED_CLIENTS", "").split(",") if c.strip()]
    if not audience and not clients:
        sys.exit(
            "FAIL: --auth=jwt needs an audience or a client id — set ENTRA_SPA_CLIENT_ID "
            "(the browser sends an ID token whose `aud` is the SPA client id), or "
            "ENTRA_ALLOWED_AUDIENCE / ENTRA_ALLOWED_CLIENTS explicitly."
        )

    config: dict = {"discoveryUrl": discovery}
    if audience:
        config["allowedAudience"] = [audience]
    if clients:
        config["allowedClients"] = clients
    print(f"  discoveryUrl : {discovery}")
    print(f"  allowedAudience: {config.get('allowedAudience', '-')}  allowedClients: {config.get('allowedClients', '-')}")
    return config


def report_inbound_auth(info: dict, intended: str) -> None:
    """Say what the runtime's inbound auth ACTUALLY is after the deploy.

    Worth a call: the proxy's routing decision is made from the catalog's synced
    copy of this, and an update that silently kept an old authorizer would send
    every request to the wrong signing path. Reading it back is also the only way
    to learn that AgentCore does not drop an existing authorizer when an update
    omits it — if that is what happened, this line is where it becomes visible.
    """
    authorizer = (info.get("authorizerConfiguration") or {}).get("customJWTAuthorizer")
    actual = "jwt" if authorizer else "iam"
    print(f"    inbound auth on the runtime: {actual}")
    if actual != intended:
        print(
            f"!!  WARNING: asked for {intended} but the runtime reports {actual}. "
            "Re-check the deploy, and re-sync the catalog before using this agent — "
            "the proxy signs on the catalog's copy of this value."
        )


def wait_until_ready(control, runtime_id: str) -> dict:
    deadline = time.time() + READY_TIMEOUT_SECONDS
    while time.time() < deadline:
        info = control.get_agent_runtime(agentRuntimeId=runtime_id)
        status = info["status"]
        print(f"  status: {status}")
        if status == "READY":
            return info
        if status in ("CREATE_FAILED", "UPDATE_FAILED"):
            sys.exit(f"FAIL: runtime entered {status}: {info.get('failureReason', 'no reason given')}")
        time.sleep(POLL_SECONDS)
    sys.exit(f"FAIL: runtime not READY within {READY_TIMEOUT_SECONDS} seconds")


def main() -> None:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    flags = [a for a in sys.argv[1:] if a.startswith("--")]
    known = ("--runtime=", "--auth=", "--config-only")
    target = next((f.split("=", 1)[1] for f in flags if f.startswith("--runtime=")), "")
    auth_flag = next((f.split("=", 1)[1].lower() for f in flags if f.startswith("--auth=")), "")
    config_only = "--config-only" in flags
    if (
        len(args) != (1 if config_only else 2)
        or any(not f.startswith(known) for f in flags)
        or auth_flag not in ("", "iam", "jwt")
    ):
        sys.exit(
            "usage: deploy_agent.py <agent-name> <zip-path> [--runtime=<name-or-arn>] [--auth=iam|jwt]\n"
            "       deploy_agent.py <agent-name> --config-only [--runtime=…] [--auth=…]\n"
            "  --runtime      update an EXISTING runtime whose name this script would not\n"
            "                 guess — e.g. one created by hand in the AgentCore console.\n"
            "  --auth         inbound auth for the runtime. Default: jwt for the agents in\n"
            "                 JWT_AUTH_AGENTS, iam for every other. jwt needs ENTRA_TENANT_ID\n"
            "                 (or ENTRA_DISCOVERY_URL) and an audience in .env.\n"
            "  --config-only  apply runtime CONFIG to an existing runtime and keep the code\n"
            "                 it is already running: no zip, no build, no upload. For changes\n"
            "                 that live on the runtime rather than in the package — the header\n"
            "                 allowlist, the authorizer, env vars. Re-uploading 37-51 MB per\n"
            "                 agent to change a config field also replaces the bytes of a\n"
            "                 working agent, which is a real risk taken for no reason."
        )
    agent_name = args[0]
    zip_arg = args[1] if not config_only else ""
    if agent_name not in CATALOG_AGENT_IDS:
        sys.exit(
            f"FAIL: unknown agent name, expected one of {sorted(CATALOG_AGENT_IDS)} "
            "(add a brand-new agent to CATALOG_AGENT_IDS first)"
        )
    zip_path = Path(zip_arg).resolve() if zip_arg else None
    if zip_path and not zip_path.exists():
        sys.exit(f"FAIL: zip not found: {zip_path}")

    env = load_env()
    region = require(env, "AWS_REGION")
    # No upload in config-only mode, so a deploy bucket is not needed to run one.
    bucket = "" if config_only else require(env, "DEPLOY_BUCKET")
    role_arn = require(env, "EXECUTION_ROLE_ARN")
    inbound_auth = auth_flag or ("jwt" if agent_name in JWT_AUTH_AGENTS else "iam")

    session = boto3.Session(region_name=region)
    s3 = session.client("s3", config=S3_CONFIG)
    control = session.client("bedrock-agentcore-control")

    # Resolve the deploy target BEFORE touching S3: the catalog (what the proxy
    # routes on) wins; the naming convention is only the fallback for an agent
    # the catalog does not know yet.
    derived_name = runtime_name_for(agent_name)
    catalog = resolve_catalog_target(env, agent_name, derived_name)
    if catalog:
        runtime_id = catalog["runtime_arn"].rsplit("/", 1)[-1]
        print(f"Catalog: '{catalog['agent_id']}' routes to {catalog['runtime_arn']}")
        catalog_runtime_name = catalog["runtime_name"] or runtime_id.rsplit("-", 1)[0]
        if catalog_runtime_name != derived_name:
            warn_catalog_divergence(control, catalog, derived_name)
        try:
            control.get_agent_runtime(agentRuntimeId=runtime_id)
        except ClientError as error:
            code = error.response.get("Error", {}).get("Code", "unknown")
            sys.exit(
                f"FAIL: the catalog routes '{catalog['agent_id']}' to {catalog['runtime_arn']} "
                f"but that runtime cannot be fetched ({code}). Fix the catalog entry (re-sync "
                "from AgentCore or edit it on /admin) and retry — deploying to a name-derived "
                "runtime instead would ship code the app never serves."
            )
        existing = {"agentRuntimeId": runtime_id}
    else:
        existing = find_existing_runtime(control, derived_name)

    object_key = f"{agent_name}/deployment_package.zip"
    if not config_only:
        ensure_bucket(s3, bucket, region)
        size_mb = zip_path.stat().st_size / (1024 * 1024)
        print(f"Uploading {zip_path.name} ({size_mb:.0f} MB) to s3://{bucket}/{object_key}")
        s3.upload_file(str(zip_path), bucket, object_key, Config=S3_TRANSFER)

    # `existing` is already resolved above — catalog first, else the name-derived
    # runtime. An explicit --runtime overrides that with a runtime the naming
    # convention could not reach; resolve_target() exits if the name/ARN is
    # unknown, so a returned value is always a real runtime. Either way, an update
    # must merge onto the target runtime's existing env vars.
    if target:
        existing = resolve_target(control, target)
        print(f"Updating explicitly targeted runtime: {existing['agentRuntimeName']}")
    env_vars = build_env_vars(env, control, existing["agentRuntimeId"] if existing else None)
    if "BEDROCK_ENDPOINT_URL" in env_vars and "BEDROCK_API_KEY" in env_vars:
        print("Gateway config present: BEDROCK_ENDPOINT_URL + BEDROCK_API_KEY set on the runtime")
        print("  (only a cloud_deploy/agents/ build can use these; a Phase0/agents/ build ignores them)")

    # Config-only keeps whatever code the runtime is already serving. update is a
    # full PUT, so the artifact still has to be sent — read it back from the
    # runtime rather than rebuilding a description of it, which is the difference
    # between "unchanged" and "identical as far as I can tell".
    if config_only:
        if not existing:
            sys.exit(
                f"FAIL: --config-only updates an existing runtime, and none was found for "
                f"'{agent_name}'. Deploy it with a zip first."
            )
        current = control.get_agent_runtime(agentRuntimeId=existing["agentRuntimeId"])
        artifact = current["agentRuntimeArtifact"]
        print(f"Config-only: keeping the code {current['agentRuntimeName']} already runs (no upload)")

    runtime_config = {
        "agentRuntimeArtifact": artifact
        if config_only
        else {
            "codeConfiguration": {
                "code": {"s3": {"bucket": bucket, "prefix": object_key}},
                "runtime": "PYTHON_3_13",
                # The opentelemetry-instrument prefix is what turns traces on, and
                # it is the ONLY thing that does. AgentCore always ships stdout to
                # the runtime's log group, so logs looked fine while spans never
                # existed: on 2026-07-22 every runtime had an `otel-rt-logs` stream
                # the platform had created and nothing had ever written to, and the
                # `bedrock-agentcore` metric namespace was empty. "Observability is
                # automatic on Runtime" in the docs means automatic ONCE ADOT is in
                # the zip and the entry point is wrapped — not on its own.
                #
                # This is one half of a pair. The other is aws-opentelemetry-distro
                # in each agent's requirements.txt: without it the runtime cannot
                # resolve the executable and never goes healthy, which surfaces as
                # an unhelpful initialization timeout. Deploying a zip built before
                # that dependency landed will fail exactly that way — rebuild it.
                "entryPoint": ["opentelemetry-instrument", "agent.py"],
            }
        },
        "roleArn": role_arn,
        "networkConfiguration": {"networkMode": "PUBLIC"},
        "protocolConfiguration": {"serverProtocol": "AGUI"},
        "environmentVariables": env_vars,
    }
    # See RELAY_HEADERS: without this the runtime hands agent code no headers at all.
    allowlist = list(RELAY_HEADERS)
    if inbound_auth == "jwt":
        runtime_config["authorizerConfiguration"] = {"customJWTAuthorizer": jwt_authorizer(env)}
        # Only legal alongside a customJWTAuthorizer, and only useful there: under
        # IAM this header carries the SigV4 signature, never a user token.
        allowlist.append("Authorization")
        print("Inbound auth: JWT (the caller's Entra token; the proxy forwards it instead of SigV4)")
    else:
        print("Inbound auth: IAM/SigV4 (the backend proxy signs with the host's AWS credentials)")
    runtime_config["requestHeaderConfiguration"] = {"requestHeaderAllowlist": allowlist}
    print(f"Header allowlist: {', '.join(allowlist)}")

    if existing:
        runtime_id = existing["agentRuntimeId"]
        print(f"Updating runtime {runtime_id}")
        control.update_agent_runtime(agentRuntimeId=runtime_id, **runtime_config)
    else:
        print(f"Creating runtime {derived_name} (name-derived — first deploy of a new agent)")
        created = control.create_agent_runtime(agentRuntimeName=derived_name, **runtime_config)
        runtime_id = created["agentRuntimeId"]

    info = wait_until_ready(control, runtime_id)
    runtime_arn = info["agentRuntimeArn"]
    print(f"OK: runtime READY, {runtime_arn}")
    report_inbound_auth(info, inbound_auth)
    if catalog:
        print(f"    the catalog routes '{catalog['agent_id']}' here — the live app serves this build")
    else:
        print("    resolved by NAME, not via the catalog — after the next AgentCore sync,")
        print(f"    verify on /admin that the catalog entry for {agent_name} routes to this ARN")


if __name__ == "__main__":
    main()
